#!/usr/bin/env python3

from brain_games.brain_even_game import brain_even_game, game


def main():
    brain_even_game(game)


if __name__ == '__main__':
    main()
