#!/usr/bin/env python3

from brain_games.logic import logic, is_even


def main():
    logic(is_even)


if __name__ == '__main__':
    main()
